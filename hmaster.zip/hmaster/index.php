<?php

function indexFunction($param) {
  return $param === 'expected_value' ? 'expected output' : 'unexpected output';
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>

  <?php include 'config.php';?>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <!-- font awsome file link -->
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"
    />
    <!-- css file link -->
    <link rel="stylesheet" href="src/css/style01.css" />
    <title>Responsive Restaurant Website</title>
  </head>
  <body>
    <!-- header start -->
    <header>
      <a href="#" class="logo"><i class="fas fa-utensils"></i>Hot Master.</a>
      <nav class="navbar">
        <a href="#home" class="active">home</a>
        <a href="#dishes">dishes</a>
        <a href="#about">about</a>
        <a href="#menu">menu</a>
        <a href="#review">review</a>
        <a href="#order">order</a>
      </nav>
      <div class="icons">
        <i class="fas fa-bars" id="menu-btn"></i>
        <i class="fas fa-search" id="search-btn"></i>
        <i class="fas fa-shopping-cart" id="cart-btn"></i>
        <i class="fas fa-heart" id="fav-btn"></i>
      </div>
      <!-- search form -->
      <form action="" class="search-form">
        <input type="search" id="search-box" placeholder="search" />
        <label for="search-box" class="fas fa-search"></label>
      </form>
      <!-- sopping cart -->
      <div class="shopping-cart">
        <div class="box">
          <i class="fas fa-trash"></i>
          <img src="src/img/home-img-1.png" alt="" />
          <div class="content">
            <h3>spicy noodlees</h3>
            <span class="price">$3.99</span>
            <span class="quantity">qty : 1</span>
          </div>
        </div>
        <div class="box">
          <i class="fas fa-trash"></i>
          <img src="src/img/home-img-2.png" alt="" />
          <div class="content">
            <h3>fried chiken</h3>
            <span class="price">$3.99</span>
            <span class="quantity">qty : 1</span>
          </div>
        </div>
        <div class="box">
          <i class="fas fa-trash"></i>
          <img src="src/img/home-img-3.png" alt="" />
          <div class="content">
            <h3>hot pizza</h3>
            <span class="price">$3.99</span>
            <span class="quantity">qty : 1</span>
          </div>
        </div>
        <div class="total">total : $10.99</div>
        <a href="#" class="btn">checkout</a>
      </div>
      <!-- favorite form -->
      <form action="" class="fav-form">
        <h3 class="head">favorite</h3>
        <div class="box">
          <i class="fas fa-trash"></i>
          <img src="src/img/home-img-2.png" alt="" />
          <div class="content">
            <h3>fried chiken</h3>
            <span class="price">$3.99</span>
            <span class="quantity">qty : 1</span>
          </div>
        </div>
        <div class="box">
          <i class="fas fa-trash"></i>
          <img src="src/img/home-img-3.png" alt="" />
          <div class="content">
            <h3>hot pizza</h3>
            <span class="price">$3.99</span>
            <span class="quantity">qty : 1</span>
          </div>
        </div>
      </form>
    </header>
    <!-- header ends -->

    <!-- home section start -->
    <section class="home" id="home">
      <div class="content">
        <h3>get foods by <span>easy</span> payment</h3>
        <p>
        A cozy corner grocer nestled in the heart of town, our food store offers a delightful array of fresh produce, artisanal cheeses, and gourmet treats. From locally sourced specialties to international delights, we cater to every palate. 
        Step into our inviting space and let your senses indulge in a culinary adventure.
        </p>
        <a href="#order" class="btn">order now</a>
      </div>
    </section>
    <!-- home section ends -->

    <!-- dish section start -->
    <?php
  // Assuming $conn is your MySQL database connection
  $select = mysqli_query($conn, "SELECT * FROM products");
?>

<section class="dishes" id="dishes">
  <h3 class="sub-heading">our dishes</h3>
  <h1 class="heading">special <span>dishes</span></h1>
  <div class="box-container">

    <?php while($row = mysqli_fetch_assoc($select)) { ?>

    <div class="box">
      <a href="#" class="fas fa-heart"></a>
      <a href="#" class="fas fa-eye"></a>
      <img src="uploaded_img/<?php echo $row['image']; ?>"  alt="" posix_access="">
      <h3><?php echo $row['name']; ?></h3>
      <div class="stars">
        
         <div class="stars">
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star-half-alt"></i>
       </div>
       
      </div>
      <span>Rs <?php echo $row['price']; ?>/-</span>
      <a href="#" class="btn">add to cart</a>
    </div>
    <?php } ?>
  </div>
</section>

    <!-- dish section ends -->

    <!-- about section start -->
    <section class="about" id="about">
      <h3 class="sub-heading">about us</h3>
      <h1 class="heading">why <span>choose us</span></h1>
      <div class="row">
        <div class="image">
          <img src="src/img/about-img.png" alt="" />
        </div>
        <div class="content">
          <h3>best food in the country</h3>
          <p>
          Indulge Mart: Your Culinary Haven!" Offering a tantalizing array of gourmet delights,
           fresh produce, and artisanal treats, our food store promises an epicurean adventure for every palate. Immerse yourself in a world of flavor, quality, and convenience, where culinary excellence meets exceptional service. Savor the experience at Indulge Mart today!
          </p>
          <p>
            
          </p>
          <div class="icons-container">
            <div class="icons">
              <i class="fas fa-shipping-fast"></i>
              <span>fast delivery</span>
            </div>
            <div class="icons">
              <i class="fas fa-dollar-sign"></i>
              <span>easy payment</span>
            </div>
            <div class="icons">
              <i class="fas fa-headset"></i>
              <span>24/7 service</span>
            </div>
          </div>
          <a href="#" class="btn">learn more</a>
        </div>
      </div>
      <!-- about section ends -->
    </section>

    <!-- menu section start -->
    <section class="menu" id="menu">
      <h3 class="sub-heading">our menu</h3>
      <h1 class="heading">today's <span>speciality</span></h1>
      <?php
      $res = mysqli_query($conn, "SELECT * FROM products where id % 2 = 0");
?>


      <div class="box-container">

      <?php while($row = mysqli_fetch_assoc($res)) { ?>


        <div class="box">
          <div class="image">
            <img src="uploaded_img/<?php echo $row['image']; ?>" alt="" />
            <a href="#" class="fas fa-heart"></a>
          </div>
          <div class="content">
            <div class="stars">
              <i class="fas fa-star"></i>
              <i class="fas fa-star"></i>
              <i class="fas fa-star"></i>
              <i class="fas fa-star"></i>
              <i class="fas fa-star-half-alt"></i>
            </div>
            <h3><?php echo $row['name']; ?></h3>
            <p>
              Enjoy foods
            </p>
            <a href="#" class="btn">add to cart</a><br>
            <span>Rs <?php echo $row['price']; ?>/-</span>
          </div>
          
        </div>
        <?php } ?>
    </section>
    <!-- menu section ends -->

    <!-- review section start -->
    <section class="review" id="review">
      <h1 class="heading">our customers <span>reviews</span></h1>
      <div class="box-container">
        <div class="box">
          <img src="src/img/pic-1.png" alt="" />
          <h3>john deo</h3>
          <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
          </div>
          <p>
          Absolutely love shopping at this food store! The variety of fresh produce is impressive, and the quality is always top-notch. The staff are friendly and helpful,
           making the shopping experience enjoyable. Plus, they have a great selection of international foods that I can't find anywhere else in town. Highly recommend!
          </p>
        </div>
        <div class="box">
          <img src="src/img/pic-2.png" alt="" />
          <h3>john deo</h3>
          <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
          </div>
          <p>
          I've been a loyal customer of this food store for years, and it never disappoints.
           From pantry staples to specialty items, they have everything I need to create delicious meals at home. The prices are reasonable, and I appreciate that they offer organic and locally sourced options. Their deli and bakery sections are fantastic too - perfect for grabbing a quick lunch or picking up some freshly baked bread. Overall, a fantastic place to shop for groceries
          </p>
        </div>
        <div class="box">
          <img src="src/img/pic-3.png" alt="" />
          <h3>john deo</h3>
          <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
          </div>
          <p>
          This food store is a hidden gem! I stumbled upon it recently and was blown away by the quality of their products. The produce is incredibly fresh, and I love that they support local farmers. Their prepared foods are also delicious and convenient for busy weeknights. The store is always clean and well-organized, and the staff are knowledgeable and friendly.
           I'll definitely be coming back!
          </p>
        </div>
      </div>
    </section>
    <!-- review section ends -->
    
<?php
include 'config.php';

if(isset($_POST['order_now'])) {
    // Check if the connection is established
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepare and bind parameters
    $stmt = $conn->prepare("INSERT INTO orders (full_name, email, phone_number, food_name, address) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("ssiss", $full_name, $email, $phone_number, $food_name, $address);

    // Set parameters
    $full_name = $_POST['full_name'];
    $email = $_POST['email'];
    $phone_number = $_POST['phone_number'];
    $food_name = $_POST['food_name'];
    $address = $_POST['address'];

    // Execute the statement
    if ($stmt->execute()) {
        echo "<script>alert('Order placed successfully!');</script>";
        echo "<script>window.location.href='index.php#order';</script>";
        

      } else {
        echo "<script>alert('Error: " . $stmt->error . "');</script>";
    }

    // Close statement
    $stmt->close();
    
    // Close connection
    $conn->close();
}
?>

    ?>


    <!-- order section start -->
    <section class="order" id="order">
      <h1 class="heading"><span>order</span> now</h1>
      <div class="row">
        <div class="image">
          <img src="src/img/waiter.jpg" alt="" />
        </div>
        <form  method="post">
          <div class="inputBox">
            <input type="text" placeholder="Full Name" name="full_name" required />
            <input type="email" placeholder="example@gmial.com" name="email" required />
          </div>
          <div class="inputBox">
            <input type="number" placeholder="Number" name="phone_number" required />
            <input type="text" placeholder="Food Name" name="food_name" required />
          </div>
          <textarea
            placeholder="Address"
            name="address"
            id=""
            cols="30"
            rows="10"
          ></textarea>
          <input type="submit" value="order now" class="btn" name="order_now" />
        </form>
      </div>
    </section>
    <!-- order section ends -->

    <!-- footer start -->
    <footer class="footer" id="footer">
      <div class="box-container">
        <div class="box">
          <h3>loaction</h3>
          <a href="#">colombo</a>
          <a href="#">dehiwala</a>
          <a href="#">Maharagama</a>
          <a href="#">kottawa</a>
          <a href="#">Nugegoda</a>
        </div>
        <div class="box">
          <h3>quick links</h3>
          <a href="#home">home</a>
          <a href="#dishes">dishes</a>
          <a href="#about">about</a>
          <a href="#menu">menu</a>
          <a href="#review">review</a>
          <a href="#order">order</a>
        </div>
        <div class="box">
          <h3>contact info</h3>
          <a href="#">0771225168</a>
        <!--  <a href="#">+5555 555 555</a>
          <a href="#">+5555 555 555</a> -->
          <a href="#">madhuwantha83@gmail.com</a>
        <!--  <a href="#">example@gmail.com</a> -->
        </div>
        <div class="box">
          <h3>follow us</h3>
          <a href="#">facebook</a>
          <a href="#">twitter</a>
          <a href="#">intagram</a>
          <a href="#">linkedin</a>
        </div>
      </div>
      <div class="credit">
        ©copyright @ 2024 designed by: <span>Madhuwantha</span>
      </div>
    </footer>
    <!-- footer ends -->

    <!-- scroll btn -->
    <a href="#home" class="fas fa-angle-up" id="scroll-top"></a>

    <!-- js file link -->
    <script src="src/script/script.js"></script>
  </body>
</html>
