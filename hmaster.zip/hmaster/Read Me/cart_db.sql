-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 11, 2024 at 11:36 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cart_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone_number` varchar(15) NOT NULL,
  `food_name` varchar(255) NOT NULL,
  `address` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `full_name`, `email`, `phone_number`, `food_name`, `address`) VALUES
(1, 'nmn', 'tbjntn22@ntklngkln', '7', 'kottu', 'yj'),
(2, 'thilna', 'tbjntn22@ntklngkln', '7', 'kottu', 'no'),
(3, 'thilna', 'tbjntn22@ntklngkln', '7', 'kottu', 'no'),
(4, 'thilna', 'tbjntn22@ntklngkln', '7', 'kottu', 'no'),
(25, 'madhuwantha', 'naavodya@gmail.com', '780000000', 'kottu', 'hjnjkrn'),
(26, 'nimal', 'nimal@gmail.com', '79658958', 'bun', 'hfhies'),
(27, 'thilina', 'thilina@gmail.com', '729697079', 'htnkf', 'higtokhj'),
(28, 'thkjlkeg', 'hgio@fnvj', '9790', 'hfiu', 'dhkf');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `price`, `image`) VALUES
(47, 'Biriyani', '2100', '1.png'),
(48, 'Burger', '1200', '2.png'),
(49, 'Pot Biriyani', '2300', '7.png'),
(50, 'Mix Pizza ', '3200', '30.png'),
(51, 'Sosejas Pizza', '1700', '27.png'),
(52, 'Pasta', '1300', '4.png'),
(53, 'Red Sauce Pasta', '1300', '5.png'),
(54, 'Prawns Plate', '2100', '12.png'),
(55, 'Beef Burger', '1800', '14.png'),
(57, 'Beef Pizza', '2100', '33.png'),
(58, 'Fish Plate', '1900', '40.png'),
(59, 'Roast Chicken', '2900', '13.png'),
(60, 'Hot Dog', '1200', '15.png'),
(61, 'Noodles', '1200', '9.png'),
(62, 'Egg Salad Plate', '1200', '6.png'),
(63, 'Chicken Rice', '1800', '10.png'),
(64, 'Italian Tuna Pizza', '1300', '29.png'),
(65, 'Chicken Rice', '1800', '10.png'),
(66, 'French Fries', '700', '11.png'),
(67, 'Chocolate Cake', '3700', '43.png'),
(68, 'Strawberry Cake', '4200', '42.png'),
(69, 'Icing Cake', '1500', '44.png'),
(70, 'Dark Chocolate Cake', '4500', '41.png'),
(71, 'Chicken Bucket', '2800', '38.png');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `user_name`, `password`, `name`) VALUES
(4, 'Madhuwantha', '12345', 'Madhuwantha');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=72;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
